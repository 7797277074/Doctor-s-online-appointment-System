<div class="splash-footer">
    &copy; <?php echo date ('Y');?>
    Online Doctor Appointment Booking System | Powered By 
    <a href = "" target ="_blank" >YouCare</a>
</div>
