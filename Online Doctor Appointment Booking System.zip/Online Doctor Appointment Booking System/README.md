# Appointment_Manager

Online Doctor Appointment Booking System is a web based appointment management system crafted using core php.

<hr>

<hr>
<b>Login Credentials</b><br>
<b> 1.Admin Acoount</b>
<li>sysadmin@gmail.com</li>
<li>admin</li>

<hr>
<b>Login Credentials</b><br>
<b> 2.Dummy Client</b>
<li>sayan@gmail.com</li>
<li>123</li>
<hr>
<b>Login Credentials</b><br>
<b> 3.Dummy Doctor</b>
<li>demodoc@tms.com</li>
<li>demodoc</li>
<hr>

<hr>
